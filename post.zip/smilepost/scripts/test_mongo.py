import os
import certifi
from pymongo import MongoClient
from dotenv import load_dotenv

load_dotenv()

MONGODB_URI = os.getenv("MONGODB_URI")
DB_NAME = os.getenv("DB_NAME", "smilepost")

def test_connection():
    if not MONGODB_URI:
        print("❌ MONGODB_URI not found in .env file")
        return

    print(f"📡 Attempting to connect to MongoDB...")
    try:
        client = MongoClient(MONGODB_URI, tlsCAFile=certifi.where())
        client.admin.command('ping')
        print("✅ Connection successful!")
        
        db = client[DB_NAME]
        print(f"📂 Using database: {DB_NAME}")
        
        # Check collections
        collections = db.list_collection_names()
        print(f"📦 Collections: {collections}")
        
    except Exception as e:
        print(f"❌ Connection failed: {e}")

if __name__ == "__main__":
    test_connection()
