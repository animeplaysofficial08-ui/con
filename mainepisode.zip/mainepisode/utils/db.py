import os
import json
import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo.errors import OperationFailure
try:
    from config import MONGO_URI
except ImportError:
    MONGO_URI = None

# ================= MongoDB / Hybrid Setup =================
USE_MONGODB = False
client = None
db = None
settings_col = None
episodes_col = None

async def init_db():
    global client, db, settings_col, episodes_col, USE_MONGODB
    if not MONGO_URI:
        print("⚠️ No MONGO_URI found in config.py. Using JSON mode.")
        return

    try:
        client = AsyncIOMotorClient(MONGO_URI, serverSelectionTimeoutMS=5000)
        # Verify connection (Trigger auth check)
        await client.admin.command('ping')
        
        db = client["auto_forwarder"]
        settings_col = db["settings"]
        episodes_col = db["episodes"]
        USE_MONGODB = True
        print("✅ Connected to MongoDB successfully!")
    except OperationFailure:
        print("❌ MongoDB Auth Failed (Bad URI/Credentials). Falling back to JSON.")
    except Exception as e:
        print(f"⚠️ MongoDB Connection Error: {e}. Falling back to JSON.")

# ================= SETTINGS (STORAGE) =================
async def get_settings():
    if USE_MONGODB:
        try:
            doc = await settings_col.find_one({"id": "main_settings"})
            if doc: return doc["data"]
            
            # Migration from JSON to DB
            default = load_json("storage.json", {"enabled": True, "maps": {}, "replace_at": "@Hindi_Animes_Series", "language": "Hindi"})
            await save_settings(default)
            return default
        except:
            pass
            
    return load_json("storage.json", {"enabled": True, "maps": {}, "replace_at": "@Hindi_Animes_Series", "language": "Hindi"})

async def save_settings(data):
    if USE_MONGODB:
        try:
            await settings_col.update_one({"id": "main_settings"}, {"$set": {"data": data}}, upsert=True)
            return
        except:
            pass
    save_json("storage.json", data)

# ================= LEGACY HELPERS =================
def load_json(f, default):
    try:
        if not os.path.exists(f): return default
        with open(f, "r") as f_in: return json.load(f_in)
    except: return default

def save_json(f, d):
    try:
        with open(f, "w") as f_out: json.dump(d, f_out, indent=2)
    except: pass
